package bowling_Package;

import java.util.*;

public class Main 
{
	public static void main(String[] Args)
	{
		Scanner input = new Scanner(System.in);
		
		int randomRoll = (int)(Math.random() * 11); //Generates pins knocked down randomly.
		
		RollTheBall rolling = new RollTheBall(); //Creates the act of rolling the ball object.
		
		rolling.rollI(randomRoll); //Calls rolling the ball method.
		
	}
}
