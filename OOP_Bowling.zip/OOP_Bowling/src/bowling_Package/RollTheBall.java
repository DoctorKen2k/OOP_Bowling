package bowling_Package;

public class RollTheBall 
{
	public int roll; //Holds random generated number from Main class.
	
	public RollTheBall()
	{
		//Blank constructor.
	}
	
	public int rollI(int roll) //Acts as scoring when a player rolls the ball for the first time.
	{
		int strike = 10; //Initializes strike.
		int remaining = 0; //Initializes remaining pins after first roll.
		
		if(roll == strike) //Determines if a strike was rolled or not.
		{
			System.out.println("YOU ROLLED A STRIKE!");
		}
		else if(roll < strike)
		{
			remaining = strike - roll;
			System.out.println("You have " + remaining + " pins left.");
		}
		return roll;
	}

	

}
