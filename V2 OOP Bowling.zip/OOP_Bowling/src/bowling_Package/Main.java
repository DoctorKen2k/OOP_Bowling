package bowling_Package;

import java.util.*;

public class Main 
{
	public static void main(String[] Args)
	{
		//Scanner input = new Scanner(System.in);
		
		int remaining = 0;
		
		int roll = (int)(Math.random() * 11); //Generates pins knocked down randomly.
		
		RollTheBall rolling = new RollTheBall(); //Creates the act of rolling the ball object for the first frame.
		rolling.frame(roll, remaining); //Calls rolling the ball method for first frame.
		
		RollTheBall2 rolling2 = new RollTheBall2(); //Creates the act of rolling the ball object for the second frame.
		rolling2.frame2(roll, remaining); //Calls rolling the ball method for the second frame.
		
	}
}
