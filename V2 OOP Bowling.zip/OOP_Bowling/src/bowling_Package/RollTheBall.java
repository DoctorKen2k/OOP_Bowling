package bowling_Package;

public class RollTheBall 
{
	public int roll; //Holds random generated number from Main class.
	public int remaining; //Remaining pins.
	
	public RollTheBall()
	{
		//Blank constructor.
	}
	
	public int frame(int[] turnOneArray, int roll, int remaining) //Acts as scoring when a player rolls the ball for the first time.
	{
		int turnOne;
		int strike = 10; //Initializes strike.
		//int remaining = 0; //Initializes remaining pins after first roll.
		
		if(roll == strike) //Determines if a strike was rolled or not.
		{
			System.out.println("YOU ROLLED A STRIKE!");
		}
		else if(roll < strike)
		{
			remaining = strike - roll;
			System.out.println("You knocked down " + roll + " pin(s).");
			System.out.println("You have " + remaining + " pin(s) left.");
		}
		turnOneArray(roll, remaining);
		turnOne = turnOneArray;
		
		return turnOne;
	}
	
	
	

}
