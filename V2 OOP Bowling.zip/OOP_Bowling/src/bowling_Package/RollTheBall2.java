package bowling_Package;

public class RollTheBall2 extends RollTheBall
{
	public int roll;
	public int remaining;
	
	public RollTheBall2()
	{
		//Blank constructor.
	}
	
	public int frame2(int roll, int remaining) //Acts as scoring when a player rolls the ball for the second time.
	{
		int spare = remaining; //Initializes spare.
		
		if(roll == remaining) //Determines if a spare was rolled or not.
		{
			System.out.println("YOU ROLLED A SPARE!");
		}
		else if(roll < spare)
		{
			remaining = spare - roll;
			System.out.println("You have " + remaining + " pins left.");
		}
		return roll;
	}
	
	
}
