package package_bowling;

public class Main 
{
	public static void main(String[] Args)
	{
		int roll = ((int)(Math.random() * 11)); //Generates a random number to act as how many pins were knocked down.
		RollTheBall rolling = new RollTheBall(); //Creates the act of rolling the ball object for the first frame.
		rolling.frame(roll); //Calls rolling the ball method for first frame.
		
		System.out.println(""); //Space for the output.
		
		int roll2 = (rolling.getRemaining() - ((int)(Math.random() * rolling.getRemaining()))); //Generates a random number to act as how many pins were knocked down.
		rolling.getRemaining(); //Returns remaining pins from first roll.
		RollTheBall2 rolling2 = new RollTheBall2(); //Creates the act of rolling the ball object for the second frame.
		rolling2.frame(roll2, rolling.getScore(), rolling.getRemaining()); //Calls rolling the ball method for the second frame.
	}
}
