package package_bowling;

public class RollTheBall 
{
	public int remaining; //Remaining pins.
	public int score; //Current score.
	
	public RollTheBall()
	{
		//Blank constructor.
	}
	
	public void setRemaining(int remaining)
	{
		this.remaining = remaining;
	}
	
	public int getRemaining()
	{
		return remaining;
	}
	
	public void setScore(int score)
	{
		this.score = score;
	}
	
	public int getScore()
	{
		return score;
	}
	
	public int frame(int roll) //Acts as scoring when a player rolls the ball for the first time.
	{
		int turnOne = 0;
		int strike = 10; //Initializes strike.
		
		if(roll == strike) //Determines if a strike was rolled or not.
		{
			System.out.println("YOU ROLLED A STRIKE!");
			score += 20;
			System.out.println("Your score: " + getScore());
			return turnOne;
			
		}
		else if(roll < strike)
		{
			remaining = strike - roll;
			getRemaining();
			score = roll;
			
			System.out.println("You knocked down " + roll + " pin(s).");
			System.out.println("Your score: " + getScore());
			System.out.println("You have " + getRemaining() + " pin(s) left.");
			
			//return turnOne;
		}
		
		return turnOne;
	}
}
	
	
	
