package package_bowling;

public class RollTheBall2 extends RollTheBall
{
	public int roll;
	public int remaining;
	
	public RollTheBall2()
	{
		//Blank constructor.
	}
	
	public int frame(int roll, int score, int remaining) //Acts as scoring when a player rolls the ball for the second time.
	{
		int spare = remaining; //Initializes spare.
		int turnTwo = 0;
		
		if(roll == spare) //Determines if a spare was rolled or not.
		{
			System.out.println("You knocked down the remaining " + remaining + "(s).");
			System.out.println("YOU ROLLED A SPARE!");
			score = 10 + roll;
			System.out.println("Your score: " + score);
		}
		else if(roll < spare)
		{
			remaining = spare - roll;
			System.out.println("You knocked down " + roll + " pin(s).");
			System.out.println("You missed " + remaining + " pin(s).");
			score = roll + score;
			System.out.println("Your score: " + score);
		}
		return turnTwo;
	}
	
	
}
